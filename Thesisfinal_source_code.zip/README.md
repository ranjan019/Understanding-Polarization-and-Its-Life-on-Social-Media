# Thesis - IIIT Hyderabad

The simplest way to build the thesis is the following command. You need to have working latex installation on your machine.

```
$ latexmk -pdf [-xelatex] [-outdir=latex_out/] thesis
```

The parts in square brackets (`[]`) are optional.

Alternatively, you can use any editor you prefer and set it up to build `pdf` out of `latex`.

The `.tex` file are self explanatory if you have preliminary knowledge of latex.
